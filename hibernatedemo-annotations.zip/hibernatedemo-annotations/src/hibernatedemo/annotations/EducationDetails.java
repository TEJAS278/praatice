/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hibernatedemo.annotations;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**
 *
 * @author Administrator
 */
@Entity
public class EducationDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String courseName;

    @Column(nullable = false)
    private Float percentage;

    @Column(nullable = false)
    private Integer passedOutYear;

    @ManyToOne
    private Student student;

    public EducationDetails() {
    }

    public EducationDetails(Integer id, String courseName, Float percentage, Integer passedOutYear) {
        this.id = id;
        this.courseName = courseName;
        this.percentage = percentage;
        this.passedOutYear = passedOutYear;
    }

    public EducationDetails(String courseName, Float percentage, Integer passedOutYear) {
        this.courseName = courseName;
        this.percentage = percentage;
        this.passedOutYear = passedOutYear;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public Float getPercentage() {
        return percentage;
    }

    public void setPercentage(Float percentage) {
        this.percentage = percentage;
    }

    public Integer getPassedOutYear() {
        return passedOutYear;
    }

    public void setPassedOutYear(Integer passedOutYear) {
        this.passedOutYear = passedOutYear;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
    
    

    @Override
    public String toString() {
        return "EudcationDetails{" + "id=" + id + ", courseName=" + courseName + ", percentage=" + percentage + ", passedOutYear=" + passedOutYear + '}';
    }

}
