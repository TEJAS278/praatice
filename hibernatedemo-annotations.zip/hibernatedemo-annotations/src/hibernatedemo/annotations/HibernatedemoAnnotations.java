/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hibernatedemo.annotations;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author Administrator
 */
public class HibernatedemoAnnotations {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Configuration config = new Configuration();

        Properties properties = new Properties();
        properties.setProperty("hibernate.connection.driver_class", "com.mysql.cj.jdbc.Driver");
        properties.setProperty("hibernate.connection.url", "jdbc:mysql://localhost:3306/hibernatedemo");
        properties.setProperty("hibernate.connection.username", "root");
        properties.setProperty("hibernate.connection.password", "root");
        properties.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL57InnoDBDialect");
        properties.setProperty("hibernate.hbm2ddl.auto", "create");
        properties.setProperty("hibernate.show_sql", "true");

        config.setProperties(properties);
        config.addAnnotatedClass(Student.class);
        config.addAnnotatedClass(Address.class);
        config.addAnnotatedClass(EducationDetails.class);
        config.addAnnotatedClass(Course.class);

        SessionFactory sessionFactory = config.buildSessionFactory();

        Student student = new Student("ravi", "ravi@gmail.com", new Date(1996 - 1900, 4, 16));
        Address address = new Address("Hyd", "500038");

        //address.setStudent(student);
        student.setAddress(address);

        EducationDetails sscDetails = new EducationDetails("SSC", 87.98F, 2008);
        EducationDetails interDetails = new EducationDetails("Intermediate", 78.96F, 2010);
        EducationDetails graduationDetails = new EducationDetails("B.TECH", 70.86F, 2014);

        sscDetails.setStudent(student);
        interDetails.setStudent(student);
        graduationDetails.setStudent(student);

        Course javaCourse = new Course("Java", 8000F, 2F);
        Course nodeJSCourse = new Course("NodeJS", 10000F, 1.5F);
        Course angularCourse = new Course("Angular", 12000F, 2F);
        
        
        List<Student> students = new ArrayList<Student>();
        students.add(student);
        
        nodeJSCourse.setStudents(students);
        angularCourse.setStudents(students);
        
        List<Course> courses = new ArrayList<Course>();
        courses.add(nodeJSCourse);
        courses.add(angularCourse);
        
        student.setCourses(courses);
        
        

        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        try {
            session.save(student);
            session.save(address);
            session.save(sscDetails);
            session.save(interDetails);
            session.save(graduationDetails);
            session.save(javaCourse);
            session.save(nodeJSCourse);
            session.save(angularCourse);
            session.update(student);
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            tx.rollback();
        } finally {
            session.clear();
            session.close();
        }

    }

}
