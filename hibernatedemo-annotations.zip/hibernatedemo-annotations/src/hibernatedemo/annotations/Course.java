/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hibernatedemo.annotations;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

/**
 *
 * @author Administrator
 */
@Entity
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(nullable = false, unique = true)
    private String name;

    @Column(nullable = false)
    private Float fee;

    @Column(name = "noOfDays", nullable = false)
    private Float durationInDays;

    @ManyToMany
    private List<Student> students;

    public Course() {
    }

    public Course(Integer id, String name, Float fee, Float durationInDays) {
        this.id = id;
        this.name = name;
        this.fee = fee;
        this.durationInDays = durationInDays;
    }

    public Course(String name, Float fee, Float durationInDays) {
        this.name = name;
        this.fee = fee;
        this.durationInDays = durationInDays;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Float getFee() {
        return fee;
    }

    public void setFee(Float fee) {
        this.fee = fee;
    }

    public Float getDurationInDays() {
        return durationInDays;
    }

    public void setDurationInDays(Float durationInDays) {
        this.durationInDays = durationInDays;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

   

    @Override
    public String toString() {
        return "Course{" + "id=" + id + ", name=" + name + ", fee=" + fee + ", durationInDays=" + durationInDays + '}';
    }

}
