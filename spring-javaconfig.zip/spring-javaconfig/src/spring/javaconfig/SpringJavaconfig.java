/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spring.javaconfig;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 *
 * @author Administrator
 */
public class SpringJavaconfig {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringAppConfig.class);
//        Bike bike = context.getBean(Bike.class);
//        System.out.println(bike);
        Car car = context.getBean(Car.class);
        System.out.println(car);
        Person person = context.getBean(Person.class);
        System.out.println(person);
        
        System.out.println(person.getVehicle());

//       Person person = context.getBean(Person.class);
//       
//        System.out.println(bike);
//        System.out.println(person);
//        
//        System.out.println(person.getVehicle());
    }

}
