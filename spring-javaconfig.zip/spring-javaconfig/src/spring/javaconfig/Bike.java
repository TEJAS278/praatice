/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spring.javaconfig;

import org.springframework.stereotype.Component;

/**
 *
 * @author Administrator
 */

@Component
public class Bike implements Vehicle {

    @Override
    public void run() {
        System.out.println("Bike ride");
    }

}
