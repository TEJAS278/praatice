package dsa;

import java.util.Scanner;

public class FactorialUsingRecursion {

	public static void main(String[] args) {

Scanner  scanner=new Scanner(System.in);
System.out.println("Enter number");
int num=scanner.nextInt();
int factorial=findFact(num);
System.out.println("Factorilal  of "+num + " = "+factorial);
	}
	//assume n value is 5
	public static int findFact(int n)
	{
		if(n==1)
		{
			return 1;
		}
		else
		{
		return n*findFact(n-1);
		}
		
	}

}
