package dsa;

public class DLTest {

	public static void main(String[] args) {

DList dl=new DList();
dl.push(30);//30
dl.push(80);//80 30
dl.push(60);// 60 40 30
dl.append(23);//  60 40 30 23 
dl.push(33);//33 60 40 30 23
dl.printDl(dl.head);// expected output ->60 40 30 23 
dl.insertAfterNode(dl.head, 94);
dl.printDl(dl.head);//33	94	60	80	30	23
//dl.head=dl.head.next;
//dl.head=dl.head.next;
dl.insertAfterNode(dl.head.next.next, 70);
dl.printDl(dl.head);
	}

}
