package dsa;

public class List 
{
Node head;
	static class Node
	{
		int data;
		Node  next;
		
		Node(int data)
		{
			this.data=data;
			next=null;
		}
	}//Node class
	//insertNode(list,34);
	public static List insertNode(List list,int data)
	{
		//create new node
		Node n=new Node(data);
		n.next=null;
		
		if(list.head==null)
		{
			//if the node is 1st node in list
			list.head=n;
		}
		else
		{
			// if the node is not 1st node
			//insert new node at last node
			Node last=list.head;
			while(last.next!=null)
			{
				last= last.next;
			}
			//insert new node (l ) at last position
			last.next=n;
			
			
		}
		return list;
	}//insertNode
	
	public static void displayList(List list)
	{
		Node presentNode=list.head;
		
		while(presentNode!=null)
		{
			System.out.println("[");
			System.out.print(presentNode.data+"]  [");
			System.out.print(presentNode+"] \t ");
			
			presentNode=presentNode.next;
		}
		
	}
	
}
