package dsa;

import javax.sql.rowset.serial.SerialArray;

public class BSTTest {

	public static void main(String[] args) 
	{
BST bst=new BST();

bst.root=bst.new TreeNode(52);

bst.root.leftTree=bst.new TreeNode(36);
bst.root.leftTree.leftTree=bst.new TreeNode(24);
bst.root.leftTree.rightTree=bst.new TreeNode(44);
bst.root.leftTree.rightTree.leftTree=bst.new TreeNode(40);
bst.root.rightTree= bst.new TreeNode(68);
bst.root.rightTree.leftTree=bst.new TreeNode(59);
bst.root.rightTree.leftTree.leftTree=bst.new TreeNode(55);
bst.root.rightTree.rightTree= bst.new TreeNode(72);

bst.insertNode(bst.root,71);
System.out.println("inorder traversal ");
bst.inorderTraversal(bst.root);
System.out.println();
//System.out.println("postorder traversal");
//bst.postOrderTraversal(bst.root);
//System.out.println();

BST.TreeNode searchResult = bst.findNode(72);
if(searchResult!=null)
{
	System.out.println("Element "+searchResult.data+ " is found ");
}
else if(searchResult==null)
{
	System.out.println("Element  not found ");
}

BST.TreeNode parent= bst.findParent(72);
if(parent!=null)
{
	System.out.println("parent is  "+parent.data);
}
else if(searchResult==null)
{
	System.out.println("Element  not found so parent also not found ");
}

//bst.delete(71);
System.out.println("after deletion 71 BST looks like");
bst.inorderTraversal(bst.root);
System.out.println();

	}

}
