package dsa;

public class Stack 
{
	int arr[];
int top;
int capacity;
	public Stack(int size)
	{
	arr=new int[size];
	top=-1;
capacity=size;

	}
	
	//this method return whether stack is full
	//or not 
	public boolean isFull()
	{
		if(top==capacity-1)
		{
			//it means stack is full
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public void push(int num)
	{
		if(isFull())
		{
			System.out.println("Stack is Full");
		}
		else
		{
			top++;
			arr[top]=num;
		}
	}
	
	public int pop()
	{
		if(isEmpty())
		{
			System.out.println("Stack is under flow");
		}
	System.out.println("removing "+arr[top]);
		return arr[top--];
	}
	public boolean isEmpty()
	{
		if(top==-1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public int size()
	{
		return top+1;
	}
	
	public void display()
	{
		for(int i=top; i>-1; i--)
		{
		System.out.println(arr[i]);
		}
	}
	//peek will return top but not delete top
	//pop will return top and delete top
	public int peek()
	{
		if(isEmpty())
	{
		System.out.println("Stack is under flow");
	}
System.out.println("top element "+arr[top]);
	return arr[top];
		
	}
}
