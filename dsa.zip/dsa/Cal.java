package dsa;

public class Cal {

	void add(int x,int y)
	{
		System.out.println("Addition  = "+(x+y));
	}
int sub(int x,int y)
	{
		System.out.println("Substraction  = "+(x-y));
	return x-y;
	}
	public static void main(String[] args)
	{
Cal c=new Cal();
c.add(23, 4);//Addition  = 27
int result=c.sub(20,5);//

	}

}
