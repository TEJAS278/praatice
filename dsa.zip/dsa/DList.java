package dsa;

public class DList 
{
	Node head;
class Node
{
	
	int data;
	Node prev;
	Node next;
	
	Node(int data)
	{
		this.data=data;
	}
	
	
}
public void push(int data)
{
	//create node and assign data
	Node node=new Node(data);
	
	//assign next address and prev address
	node.next=head;
	node.prev=null;
	
	if(head!=null)
	{
		//assign node address to head.prev
		head.prev=node;
	}
	
	//shift head
	head=node;
	
}
//insert a node at after a particuler node
public void insertAfterNode(Node after,int data)
{
	//node should have address -> not null
	if(after==null)
	{System.out.println("the given node should not be  null ");
	}
	
	Node n=new Node(data);
	
	n.next=after.next;
	after.next=n;
	n.prev=after;
	
	if(n.next!=null)
	{
		n.next.prev=n;
	}
	
}

//insert a node at last position
public void append(int data)
{
	//create a node
	//store data in the node
	Node n=new Node(data);
	//list is empty or non empty
	//because inserting node at last
	n.next=null;
	
	//if list is empty
	// it means  no need to attach the node to list
	if(head==null)
	{
		n.prev=null;
		//stop executing method
		return;
	}
	//if list is not empty
	//take first node address(head variable) in a pointer
	Node ptr=head;
	//keep moving the pointer to the next node
	//until next node next value is null
	while(ptr.next!=null)
	{
	//update ptr -> move ptr to next node
		ptr=ptr.next;
		
	}
	//after loop  ptr is pointing to last node 
	//so add new node at last node 
	ptr.next=n;
	//now new node previous is null 
	//so update new node prev  as last node address
	//here ptr is pointing to last node
	n.prev=ptr;
	
	
	}
	
	


public void printDl(Node node)
{
	//Node last=null;
	
	while(node!=null)
	{
	System.out.print(node.data+"\t");

	//last=node;
	node=node.next;
	}
	System.out.println();
}

}
