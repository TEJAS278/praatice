package dsa;

public class StackUsingList 
{

	Node top;
	
	class Node
	{
		int data;
		Node next;
	}
	
	public void push(int d)
	{
		Node temp=top;
		top=new Node();
		top.data=d;
		top.next=temp;
		
	}
	
	public void displayStack(Node top)
	{
		while(top!=null)
		{
			//display present node data
			System.out.println(top.data);
			//move to next node until null
			top=top.next;
		}
	}
	
	public int pop()
	{
		if(top==null)
		{
			System.out.println("stack is empty");
		throw new EmptyStackException("no nodes in stack");
			
		}
		else
		{
		int removed= top.data;
		top=top.next;
		return removed;
		}
	}
}
