package dsa;

public class EmptyStackException extends RuntimeException
{
public EmptyStackException(String s) 
{
super(s);
	
}
}
