package dsa;

import java.util.Scanner;

//read list of elements and store  in array
//read an element to search
//print element found or not 
//if element found display index also
// if array is 34 5 6 12 2 3 44
//Enter element to search 
// 6
//6 found at 2nd index

public class SearchElement {
	static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) 
	{
int arr[]=new int[8];


for(int i=0; i<8; i++)
{
System.out.println("Enter number");
arr[i]=scanner.nextInt();

}
searchElement(arr);
}
public static void searchElement(int a[])
{int s;
	System.out.println("Enter element to search");
	s=scanner.nextInt();
	int i;
	for(i=0; i<a.length; i++)
	{
		if(s==a[i])
		{
			System.out.println("element "+a[i]+""
					+ " found at,  index"+i);
			break;
		}
		
		
	}
	if(i==a.length)
	{
	System.out.println("elemenet "+s+" not found");	
	}
	
}


}
