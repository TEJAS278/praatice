package dsa;

public class ListExample {

	public static void main(String[] args) {

List list =new List();

list=list.insertNode(list,20);
list=list.insertNode(list,5);
list=list.insertNode(list,45);

list.displayList(list);

	}

}
