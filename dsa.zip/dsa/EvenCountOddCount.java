package dsa;

import java.util.Scanner;

public class EvenCountOddCount {

	public static void main(String[] args) {
	int arrSize; 
	//declare evenCount,oddCount as 0
	int evenCount=0;
	int oddCount=0;
		//accept size of array
		Scanner s=new Scanner(System.in);
System.out.println("Enter array size");
arrSize=s.nextInt();

//declare array with the size
int arr[]=new int[arrSize];

//accept elements and store  into array
for(int i=0;  i<arrSize; i++)
{
	System.out.println("Enter element");
	arr[i]=s.nextInt();
}

//for each iteration in array 
for(int i=0; i<arrSize; i++)
{
	//if element is even then increment evenCount
		if(arr[i]%2==0)
	    {
		evenCount++;
		}
	//if element is odd then increment oddCount
	    else
	   {
		oddCount++;
		}
}//after all iterations 

//display evenCount and oddCount
System.out.println("Even Count = "+evenCount);
System.out.println("Odd Count = "+oddCount);


	}

}
