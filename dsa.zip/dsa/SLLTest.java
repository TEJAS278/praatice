package dsa;

public class SLLTest {

	public static void main(String[] args) {

SLL singleLinkedList=new SLL();
singleLinkedList.push(10);
singleLinkedList.displayList(singleLinkedList.head);//10
//singleLinkedList.push(20);//20 10
//singleLinkedList.displayList(singleLinkedList.head);//20 10
//singleLinkedList.append(45);// 20 10 45
//singleLinkedList.displayList(singleLinkedList.head);
//singleLinkedList.push(50);	//50 20 10 45
//singleLinkedList.displayList(singleLinkedList.head);
//singleLinkedList.insertAfter(singleLinkedList.head.next,89);//50 89 20 10 45
//singleLinkedList.displayList(singleLinkedList.head);
singleLinkedList.deleteNode(10);
singleLinkedList.displayList(singleLinkedList.head);
	}

}
