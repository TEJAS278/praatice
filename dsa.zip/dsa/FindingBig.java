package dsa;

import java.util.Scanner;

public class FindingBig {
	static Scanner s=new Scanner(System.in);
	static int max=0;
	public static void main(String[] args) 
	{

int arr[]=new int[10];


intialiseArray(arr);
displayArray(arr);

max=findMax(arr);


//display the max element
System.out.println("biggest number is "+max);
	}
	
	
	
	public static void intialiseArray(int ar[])
	{
		
		for(int i=0; i<10; i++)
		{
			System.out.println("Enter Number");
			ar[i]=s.nextInt();
		}
	}
	
	public static void displayArray(int a[])
	{
		for(int i=0; i<10; i++)
		{
			
		System.out.println("a["+i+"] = "+a[i]);

		}
	}
	
	public static int  findMax(int a[])
	{
		for(int i=1; i<10; i++)
		{
			if(max<a[i])
			{
				max=a[i];
			}
		}
		return max;
	}

}
