package dsa;

public class SLL
{
	Node head;
	
	class Node
	{
		int data;
		Node next;
	Node(int data)
	{
		this.data=data;
		
	}
	}
	
	public void push(int data)
	{
		Node n=new Node(data);
		
		if(head==null)
		{
			System.out.println("adding first node");
			head=n;
			//n.next=null;
			
		}
		else if(head!=null)
		{
			System.out.println("adding node at bigining");
			n.next=head;
				}
		head=n;
	}
	
	public void append(int data )
	{
	
		//create Node 
		Node n=new Node(data);
		n.next=null;
		
		if(head==null)
		{
			head=n;
		}
		else
		{
			Node ptr=head;
			while(ptr.next!=null)
			{
				ptr=ptr.next;
			}
	//after loop ptr is pointing to last node
			ptr.next=n;
			
			
		}
	}
	
	public void deleteNode(int data)
	{
		if(head==null)
		{
System.out.println("List is empty ");
		}
		Node ptr=head;
		Node prev=null;
			while(ptr!=null  )
			{
				if(ptr.data==data)
				{
					System.out.println("element deleted");
					if(ptr.next!=null)
					{
					prev.next=ptr.next;
					head=null;
					}
					return;
				}
				prev=ptr;
				ptr=ptr.next;
				
			}
				
				if(ptr==null)
				{
					System.out.println("element not found to delete");
					return;
				}
				
			
		
	}
	public void insertAfter(Node after,int data)
	{
		
		if(after==null)
		{
			System.out.println("node should not be null");
		return;
		}
		Node n=new Node(data);
		n.next=after.next;
		after.next=n;
		
	}
	public void displayList(Node head)
	{
		System.out.println("head = "+head);
		//don't modify head
		// move to next node through temp pointer
		Node temp=head;
		while(temp!=null)
		{
			System.out.print(temp.data+" ");
			temp=temp.next;
			
		}
		System.out.println("-----");
	}

}
