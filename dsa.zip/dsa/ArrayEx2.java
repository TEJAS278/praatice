package dsa;

import java.util.Scanner;

public class ArrayEx2 {

	public static void main(String[] args) {

String s[]=new String[4];

Scanner scanner=new Scanner(System.in);
for(int i=0; i<4; i++)
{
	System.out.println("Enter name");
	s[i]=scanner.next();
}

//display 
for(int i=0;  i<4; i++)
{
	System.out.println(s[i]);
}
//display for each loop (advanced loop)

for(String x:s)
{
	System.out.println(x);
}
	}

}
