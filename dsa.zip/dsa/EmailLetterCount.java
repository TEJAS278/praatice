package dsa;

import java.util.Scanner;

public class EmailLetterCount {

	public static void main(String[] args)
	{

/*
 read an email from user 
and store all the character
of email into an char array
*/
		int smallCaseCount=0;
		int capitalCaseCount=0;
		int digitCount=0;
		int specialCaseCount=0;
		
		System.out.println("Enter email ");
		Scanner s=new Scanner(System.in);
		String email=s.next();
		//toCharArray method is used to convert String to character array
		char em[]=email.toCharArray();
		
		//xyzAb@gmail.com
		
		for(int i=0; i<em.length; i++)
		{
			/*
			for each character in array 
			*/
			
			//check character is small
			if(em[i]>='a'&&em[i]<='z')
			{
				smallCaseCount++;
			}
			else
				if(em[i]>='A'&&em[i]<='Z')
				{
				capitalCaseCount++;
				}
				else
					if(em[i]>='0'&&em[i]<='9')
					{
						digitCount++;
					}
					else
					{
						specialCaseCount++;
					}
			
			
		}//after all iterations 
		
		//display smallcasecount
		System.out.println("number of small letters = "+smallCaseCount);
		//display capitalcasecount
		System.out.println("number of capital letters = "+capitalCaseCount);
		//display digitcount
		System.out.println("number of digits = "+digitCount);
		//display specialcasecount
		System.out.println("number of special letters = "+specialCaseCount);
	
	}
}
