package dsa;

import java.util.Scanner;

public class FactorialPro {

	public static void main(String[] args) {

Scanner s=new Scanner(System.in);
System.out.println("Enter Number");
int num=s.nextInt();
int factorail=findFactorial(num);
System.out.println("Factorial of "+num+" = "+factorail);
	}
	
	public static int findFactorial(int n)
	{
		int fact=1;
		
		for(int i=1;i<=n; i++)
		{
			fact=fact*i;
		}
		return fact;
	}

}
