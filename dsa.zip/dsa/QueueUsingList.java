package dsa;

public class QueueUsingList 
{
Node front,rear;
int currentSize=0;
class Node
{
	int data;
	Node next;
}

public void enQueue(int d)
{
	Node temp=rear;
	rear=new Node();
	rear.data=d;
	rear.next=null;
	if(isEmpty())
	{
		front=rear;
	}
	else
	{
		temp.next=rear;
	}
	currentSize++;
	
}
public boolean isEmpty()
{
	if(currentSize==0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

public void displayQueue(Node f)
{
	f=front;
	while(f!=null)
	{
		System.out.println(f.data);
		f=f.next;
	}
}

public int deQueue()
{
	int data=front.data;
	front=front.next;
	if(isEmpty())
	{
		rear=null;
	}
	currentSize--;
	return data;
}
}
