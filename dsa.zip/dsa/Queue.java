package dsa;

public class Queue 
{
	int arr[];
	int size=0;
	int front = 0;
	int rear =-1 ;
//number of elements stored in array is size

// maximum elements array can store  is capacity
int capacity;

Queue(int s)
{
capacity=s;	
arr = new int[capacity];
}
//add element at the end of queue
public void enQueue(int data)
{
	if(isFull())
	{
		System.out.println("queue is overflow ");
	}
	else
	{
	rear++;
	if(rear==capacity-1)
	{
		rear=0;
	}
	arr[rear]=data;
	size++;
	System.out.println(data+" is pushed into Queue");
	
	}
}

public boolean isFull()
{
	if(size==capacity)
	{
		return true;
	}
	else
	{
		return false;
	}
}
//display elements from front to rear 
public void display()
{
	for(int i = front; i<=rear; i++)
	{
		System.out.println(arr[i]);
	}
}
//remove element from the front of queue
public void deQueue()
{
	if(isEmpty())
	{
		System.out.println("Queue is empty  ");
	}
	else
	{
		System.out.println(arr[front]+" is removed ");
		size--;
		front++;
	}
}
public boolean isEmpty()
{
	if(size==0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

public int peek()
{
	return arr[front];
}


}
