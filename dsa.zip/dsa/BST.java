package dsa;

public class BST 
{
public TreeNode root;
	public class TreeNode
	{
		public int data;
		public TreeNode leftTree;
		public TreeNode rightTree;
		
		public TreeNode(int d)
		{
		data=d;
		}
		
	}
	//inorder traversal on BST will gives sorted order
	public void inorderTraversal(TreeNode node)
	{
		if(node==null)
		{
			return;
		}
		inorderTraversal(node.leftTree);
		System.out.print(node.data+" ");
		inorderTraversal(node.rightTree);
	}
	
	public void postOrderTraversal(TreeNode  node)
	{
		if(node==null)
		{
			return;
		}
		postOrderTraversal(node.leftTree);
		postOrderTraversal(node.rightTree);
		System.out.print(node.data+" ");
		
		
	}
	
	public TreeNode insertNode(TreeNode root, int key)
	{
		TreeNode current = root;
		
		TreeNode parent = null;
		BST bst=new BST();
	
		if(root==null)
		{
					return bst.new TreeNode(key);
		}
		else
		{
		
		while(current!=null)
		{
		parent =current;
			
			if(key> current.data)
			{
				current = current.rightTree;
			}
			else
				
			{
				current =  current.leftTree;
			}
				
		}//while -> end when no left/right node of current 
		System.out.println("parent found  "+ parent.data);
		
		// -> key insert at rightside
		if(key>parent.data)
		{
			//place the key at right side
			parent.rightTree = bst.new TreeNode(key); 
		}
		//-> key insert at left side
		else
		{
			//place the key at left side
			parent.leftTree = bst.new TreeNode(key);
		}
		
		}//else ->if root is not null
		
		return bst.new TreeNode(key);
	}
	
	public TreeNode findNode(int x)
	{
		
		TreeNode cN;
		TreeNode parent;
		
	cN = root;
	
		while(cN != null)
		{
			parent=cN;
			if(x==cN.data)
			{
				
				return cN;
			}
			else
			if(x<cN.data)
			{
				//move to right side
				cN = cN.leftTree; 
			}
			else
			{
				cN = cN.rightTree;
			}
			
		}
		return cN;
		
		
	}
	public TreeNode findParent(int x)
	{
		
		TreeNode cN;
		TreeNode parent;
		
	cN = root;
	parent=cN;
		while(cN != null)
		{
			
			if(x==cN.data)
			{
				
				return parent;
			}
			else
			if(x<cN.data)
			{
				parent=cN;
				//move to right side
				cN = cN.leftTree; 
			}
			else
			{parent=cN;
				cN = cN.rightTree;
			}
			
			
		}
		return cN;
		
		
	}
	public void delete(int x)
	{
		//find element to be delete
		TreeNode element=findNode(x);
		TreeNode parent = findParent(x);
		
		//check element has no children->case1
		if(element.leftTree==null && element.rightTree==null)
		{
			//check element is left side to parent
			if(parent.leftTree==element)
			{
				parent.leftTree=null;
			}
			//check element is right side to parent
			if(parent.rightTree==element)
			{
				parent.rightTree=null;
			}
		}
		//case 2.1
		//element has right child
		if(element.leftTree==null)
		{
			
			//check element is at left side of parent 
			if(parent.leftTree==element)
			{
				parent.leftTree=element.rightTree;
			}
			//element is at right side of parent 
			else
			{
				parent.rightTree=element.rightTree;
			}
		}
		//case 2.2 
		//element has left child
				if(element.rightTree==null)
				{
					
					//check element is at left side of parent 
					if(parent.leftTree==element)
					{
						parent.leftTree=element.leftTree;
					}
					// element is at right side of parent 
					else
					{
						parent.rightTree=element.leftTree;
					}
					
				}
				//case 3
				TreeNode successor = element.rightTree;
				TreeNode successorParent= element;
				//find successor minimum in right sub tree
				//
				while(successor.leftTree!=null)
				{
					successorParent= successor;
					successor =successor.leftTree;
				}
		element.data=successor.data;
		successorParent.leftTree=successor.rightTree;
		
	}
	
		
}
