package dsa;

import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {
		Scanner  s =new Scanner(System.in);

		int arr[] = {2,3,6,12,23,34,45};
//int arr[]= {12 ,23 ,3,45, 6, 2, 34};
		


//QuickSortExample quickSortExample=new QuickSortExample();
//quickSortExample.quickSort(arr, 0, arr.length-1);

//display array after sort
//quickSortExample.printArray(arr);
//call binarySearch method after sorting 
System.out.println("Enter search element");
int searchElement=s.nextInt();
int result=binarySearch(arr,0,arr.length-1,searchElement);
	
if(result==-1)
{
	System.out.println("Element Not Found ");
}
else
{
	System.out.println("Element fount at index"+result);
}
	
	}//main
	
	public static int binarySearch(int arr[],int low,
			int high,int searchElement)
	{
		
		if(high>=1)
		{
			int mid=low+(high-low)/2;
			System.out.println(mid);
		
		
		//check searchelement may be middle element
		if(arr[mid]==searchElement)
		{
			return mid;
		}
		if(arr[mid]>searchElement)
		{
		return binarySearch(arr, low, mid-1, searchElement);	
		}
		else
		{
		return binarySearch(arr, mid+1, high, searchElement);	
		}
		}
		return -1;
	}

}
