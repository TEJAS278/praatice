package dsa;

public class TestStackUsingList {

	public static void main(String[] args) {

StackUsingList stackUsingList=new StackUsingList();
System.out.println("element "+ stackUsingList.pop()+" is removed");
stackUsingList.push(10);
stackUsingList.push(45);
stackUsingList.push(55);

stackUsingList.displayStack(stackUsingList.top);
System.out.println("element "+ stackUsingList.pop()+" is removed");
stackUsingList.displayStack(stackUsingList.top);


	}

}
