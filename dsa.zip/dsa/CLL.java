package dsa;

public class CLL 
{
public class Node
{
	int data;
	Node next;
}

//insert element in CLL
Node push(Node ref,int data)
{
	Node ptr=new Node();
	Node temp=ref;
	ptr.data=data;
	ptr.next=ref;
	if(ref!=null)
	{
		while(temp.next!=ref)
		{
			temp=temp.next;
			temp.next=ptr;
		}
	}
	else
	{
		ptr.next=ptr;
	}
	ref=ptr;
	return ref;
}

public void printCL(Node head)
{
	Node temp=head;
	if(head!=null)
	{
		do
		{
			System.out.println(temp.data+"");
		temp=temp.next;	
		}
		while(temp!=head);
	}
	
}
}
