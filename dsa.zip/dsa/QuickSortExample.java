package dsa;
public class QuickSortExample {

 public static void main(String[] args) {
  // TODO Auto-generated method stub
   
  
   int arr[]={15,85,35,95,45,65,75};
   
   int n=arr.length;
   printArray(arr);
   quickSort(arr,0,n-1);
   printArray(arr);
 }
 
 public static int cutIt(int arr[],int low,int high)
 {
  int pivot=arr[high];
  int i=low-1;
  for(int j=low;j<high;j++)
  {
   if(arr[j]<=pivot)
   {
    i++;
    int temp=arr[i];
    arr[i]=arr[j];
    arr[j]=temp;
   }
  }
  int temp=arr[i+1];
  arr[i+1]=arr[high];
  arr[high]=temp;
  return i+1;
 }
 
 public static void quickSort(int arr[],int low ,int high)
 {
   if (low<high) 
   {
    int pi=cutIt(arr,low,high);
    quickSort(arr, low, pi-1);
   
    quickSort(arr, pi+1, high);
   }
 }
 
 public static void printArray(int arr[])
 {
  for(int i=0;i<arr.length;i++)
  {
   System.out.print( arr[i] +"\t");
   
  }
  System.out.println();
 }

}