package dsa;

import java.util.Scanner;

public class FindArraySum {
	static Scanner s=new Scanner(System.in);
	public static void main(String[] args) 
	{
int arr[];  int sum=0;

arr=prepareArray();
 arr=intialiseArray(arr);
sum=findSumOfArr(arr);
System.out.println("Sum of Array   = "+sum);
	}
	
	public static int[]  prepareArray()
	{
		int arrSize;
		System.out.println("Enter array size");
		
		
arrSize=s.nextInt();

int arr[]=new int[arrSize];
return arr;
	}

	public static int[] intialiseArray(int arr[])
	{
		for(int i=0; i<arr.length; i++)
		{
			System.out.println("length = "+arr.length);
			System.out.println("Enter element");
			arr[i]=s.nextInt();
		}
		return arr;
	}
	
	public static int findSumOfArr(int arr[])
	{
		int s=0;
		for(int i=0; i<arr.length; i++)
		{
			s=s+arr[i];
		}
		return s;
	}
}
