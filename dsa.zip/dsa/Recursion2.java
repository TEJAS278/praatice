package dsa;

public class Recursion2 {

	public static void main(String[] args) 
	{
		//printHello(5);//print hello 5 times 
		
		//printHello(3);//print hello 5 times
		//implement printHello accordingly
		
		//printSeries(3); 3 2 1
		printSeries(5); //5 4 3 2 1
		//printSeries(2);  2 1
	}
	public static int printHello(int n)
	{
		if(n==0)
		{
			return 99;
		}
		else
		{
			System.out.println("Hello");
			return printHello(n-1);		
		}
	
	}
	public static int printSeries(int n)
	{
		if(n==0)
		{
			return 88;//method calling itself will be stop
		}
		else
		{
		System.out.print("\t"+n);
		return printSeries(n-1);//method calling itself
		}
	}

	
}
