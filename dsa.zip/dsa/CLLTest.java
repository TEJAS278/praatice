package dsa;

public class CLLTest
{

	public static void main(String[] args)
	{
		CLL cll=new CLL();
CLL.Node head= null;
head=cll.push(head,49);
head=cll.push(head,56);
head=cll.push(head,12);

cll.printCL(head);




	}

}
