package dsa;

public class TestQueueUsingList {

	public static void main(String[] args) {

QueueUsingList queueUsingList=new QueueUsingList();

queueUsingList.enQueue(10);
queueUsingList.enQueue(20);
queueUsingList.enQueue(45);
queueUsingList.displayQueue(queueUsingList.front);
System.out.println("element  "+  queueUsingList.deQueue()+" is  removed");
queueUsingList.displayQueue(queueUsingList.front);
	}

}
