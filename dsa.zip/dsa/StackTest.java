package dsa;

public class StackTest {

	public static void main(String[] args) {

		//create a stack with some size
Stack stack=new Stack(3);
System.out.println("size of stack = "+stack.size()); //0 
stack.push(10);
System.out.println("size of stack = "+stack.size()); //1
stack.push(120);

stack.push(34);
stack.peek();//34 but 34 will not delete
stack.display();
stack.pop(); //34 but 34 will delete
stack.display();
	}

}
