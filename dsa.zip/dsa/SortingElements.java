package dsa;

import java.util.Scanner;

public class SortingElements {

	public static void main(String[] args) {

int arr[]=new int[6];
Scanner scanner=new Scanner(System.in);

for(int i=0; i<6; i++)
{
System.out.println("Enter Number");
arr[i]=scanner.nextInt();
}


int temp;
for(int j=1;j<6;j++)
{
for(int i=j; i<6;i++)
{
	
	if(arr[j-1]>arr[i])
	{
	temp=arr[j-1];
	arr[j-1]=arr[i];
	arr[i]=temp;
		
	}
}//innner for
}//outer for



System.out.println("0th index value is  "+arr[0]);
System.out.println("1st index value is  "+arr[1]);
System.out.println("2nd index value is  "+arr[2]);
System.out.println("3rd index value is  "+arr[3]);
System.out.println("4th index value is  "+arr[4]);
System.out.println("5th index value is  "+arr[5]);
	}

}
