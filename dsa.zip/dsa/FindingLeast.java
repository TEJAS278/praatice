package dsa;

import java.util.Scanner;

public class FindingLeast {

	public static void main(String[] args) {

int arr[]=new int[5];
int min;
Scanner scanner=new Scanner(System.in);

for(int i=0; i<5; i++)
{
	System.out.println("Enter number");
	arr[i]=scanner.nextInt();
}

min=arr[0];

for(int i=1; i<5; i++)
{
System.out.println("comparing "+min+" with "+arr[i]);	
	if(min>arr[i])
	{
				min=arr[i];
	}
}

System.out.println("min element is "+min);

	}

}
