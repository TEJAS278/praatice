package dsa;

public class QueueTest {

	public static void main(String[] args) 
	{
Queue queue=new Queue(5);

queue.enQueue(10);
queue.enQueue(20);
queue.enQueue(30);
System.out.println("top element is queue "+queue.peek());
queue.deQueue();

queue.display();
	}

}
