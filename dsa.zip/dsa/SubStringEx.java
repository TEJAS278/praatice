package dsa;

import java.util.Scanner;

public class SubStringEx {

	public static void main(String[] args) {

Scanner  s=new Scanner(System.in);
System.out.println("Enter First String");
String first=s.next();
System.out.println("Enter Second String");
String second=s.next();

if(first.contains(second))
{
	System.out.println("second string exist in first");
}

	}

}
