package dsa;

import java.util.Scanner;

public class ArrayEx {

	public static void main(String[] args) {

int arr[]=new int[5];
Scanner s=new Scanner(System.in);

for(int i=0; i<5; i++)
{
System.out.println("Enter Number");
arr[i]=s.nextInt();
}

//display the elements
for(int i=0; i<5; i++)
{
	System.out.println(arr[i]);
}

//let's use advanced for loop
for(int x:arr)
{
	System.out.println(x);
}


	}

}
