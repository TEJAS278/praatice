package dsa;

public class PrintPrimtUpToTen {

	public static void main(String[] args) {

int counter;
int n;




	}

}
