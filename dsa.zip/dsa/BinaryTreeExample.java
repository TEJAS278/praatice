package dsa;
class NodeType
{
	int data;
	NodeType left;
	NodeType right;
	
	public NodeType(int d)
	{
		data=d;
		left = right =null;
	}
}
public class BinaryTreeExample
{
NodeType root;

void inOrder(NodeType node)
{
	
	if(node==null)
	{
		return;
	}
	
	inOrder(node.left);
	System.out.print(node.data+" ");
	
	inOrder(node.right);
}

void postOrder(NodeType node)
{
	if(node==null)
	{
		return; 
	}
	postOrder(node.left);
	postOrder(node.right);
	System.out.print(node.data+" ");
}

void preOrder(NodeType node)
{
	if(node==null)
	{
		return;
	}
	System.out.print(node.data+" ");
	
	preOrder(node.left);
	preOrder(node.right);
}

	
	public static void main(String[] args) 
	{

BinaryTreeExample binaryTreeExample=new BinaryTreeExample();
binaryTreeExample.root=new NodeType(12);
binaryTreeExample.root.left=new NodeType(14);
binaryTreeExample.root.right=new NodeType(45);
binaryTreeExample.root.left.left=new NodeType(23);
binaryTreeExample.root.left.right=new NodeType(24);

System.out.println("printing through inorder traversal");
binaryTreeExample.inOrder(binaryTreeExample.root);
System.out.println();

System.out.println("printing through post order traversal");
binaryTreeExample.postOrder(binaryTreeExample.root);
System.out.println();

System.out.println("printing through pre order traversal");
binaryTreeExample.preOrder(binaryTreeExample.root);
System.out.println();
	}

}
