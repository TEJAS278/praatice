/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package autowiring.demo;

/**
 *
 * @author Administrator
 */
public class Car implements Vehicle{

    @Override
    public void runs() {
        System.out.println("Car ride");
    }
    
}
