/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package autowiring.demo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

/**
 *
 * @author Administrator
 */
public class AutowiringDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BeanFactory beanFactory =  new XmlBeanFactory(new ClassPathResource("spring.xml"));
        
       Car car =  beanFactory.getBean(Car.class);
        System.out.println(car);
        
        
        
//        Person preson = beanFactory.getBean(Person.class);
//        preson.drive();

        // 1. BeanFactory 2. ApplicationContext
//        ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
//        Person person = context.getBean(Person.class);
//        person.drive();

    }

}
