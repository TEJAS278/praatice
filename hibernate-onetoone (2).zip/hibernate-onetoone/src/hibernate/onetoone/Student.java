/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hibernate.onetoone;

import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 *
 * @author Administrator
 */
public class Student {

    private Integer id;
    private String name;
    private String email;
    private Date dateOfBirth;

    private Address address;

//    private List<EducationDetails> educationDetails;
    private Set<EducationDetails> educationDetails;

    private Set<Course> courses;

    public Student() {
    }

    public Student(Integer id, String name, String email, Date dateOfBirth) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
    }

    public Student(String name, String email, Date dateOfBirth) {
        this.name = name;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

//    public List<EducationDetails> getEducationDetails() {
//        return educationDetails;
//    }
//
//    public void setEducationDetails(List<EducationDetails> educationDetails) {
//        this.educationDetails = educationDetails;
//    }
    public Set<EducationDetails> getEducationDetails() {
        return educationDetails;
    }

    public void setEducationDetails(Set<EducationDetails> educationDetails) {
        this.educationDetails = educationDetails;
    }

    public Set<Course> getCourses() {
        return courses;
    }

    public void setCourses(Set<Course> courses) {
        this.courses = courses;
    }

    @Override
    public String toString() {
        return "Student{" + "id=" + id + ", name=" + name + ", email=" + email + ", dateOfBirth=" + dateOfBirth + '}';
    }

}
