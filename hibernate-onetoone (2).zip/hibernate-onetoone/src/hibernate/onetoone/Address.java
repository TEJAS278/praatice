/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hibernate.onetoone;

/**
 *
 * @author Administrator
 */
public class Address {

    private Integer id;
    private String doorNo;
    private String street;
    private String city;
    private String state;
    private String country;
    private String pincode;

    private Student student;

    public Address() {
    }

    public Address(Integer id, String doorNo, String street, String city, String state, String country, String pincode) {
        this.id = id;
        this.doorNo = doorNo;
        this.street = street;
        this.city = city;
        this.state = state;
        this.country = country;
        this.pincode = pincode;
    }

    public Address(String doorNo, String street, String city, String state, String country, String pincode) {
        this.doorNo = doorNo;
        this.street = street;
        this.city = city;
        this.state = state;
        this.country = country;
        this.pincode = pincode;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDoorNo() {
        return doorNo;
    }

    public void setDoorNo(String doorNo) {
        this.doorNo = doorNo;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    @Override
    public String toString() {
        return "Address{" + "id=" + id + ", doorNo=" + doorNo + ", street=" + street + ", city=" + city + ", state=" + state + ", country=" + country + ", pincode=" + pincode + '}';
    }

}
