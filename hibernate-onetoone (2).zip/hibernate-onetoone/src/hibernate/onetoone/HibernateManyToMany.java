/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hibernate.onetoone;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author Administrator
 */
public class HibernateManyToMany {

    public static void main(String[] args) {

        Configuration config = new Configuration();
        config.configure();
        SessionFactory sessionFactory = config.buildSessionFactory();

        Student std1 = new Student("ravi", "ravi@gmail.com", new Date(1996 - 1900, 4, 16));
        Student std2 = new Student("geetha", "geetha@gmail.com", new Date(1995 - 1900, 7, 10));
        Student std3 = new Student("santhosh", "santhosh@gmail.com", new Date(1996 - 1900, 2, 02));

        Course javaCourse = new Course("Java", 8000F, 2F);
        Course nodeJSCourse = new Course("NodeJS", 10000F, 1.5F);
        Course angularCourse = new Course("Angular", 12000F, 2F);

        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        try {
            session.save(std1);
            session.save(std2);
            session.save(std3);
            session.save(javaCourse);
            session.save(nodeJSCourse);
            session.save(angularCourse);
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();;
            tx.commit();
        } finally {
            session.clear();
            session.close();
        }

        session = sessionFactory.openSession();
        try {
            Course fetchedJavaCourse = session.get(Course.class, 1);

            Set<Student> students = new HashSet<Student>();
            students.add(std2);
            students.add(std3);

            fetchedJavaCourse.setStudents(students);

            tx = session.beginTransaction();
            session.update(fetchedJavaCourse);
            tx.commit();

        } catch (Exception e) {
            e.printStackTrace();
            tx.rollback();
        } finally {
            session.clear();
            session.close();
        }

    }

}
