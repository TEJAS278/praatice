/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hibernate.onetoone;

import java.util.Date;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author Administrator
 */
public class HibernateOnetoone {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Configuration config = new Configuration();
        config.configure();
        SessionFactory sessionFactory = config.buildSessionFactory();

        Student student = new Student("ravi", "ravi@gmail.com", new Date(1996 - 1900, 5, 27));

        Address address = new Address("2B-7/A", "SR Nager", "Hyderabad", "Telanagana", "India", "500038");

        address.setStudent(student);

        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        try {
            session.save(student);
            session.save(address);
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            tx.rollback();
        } finally {
            session.clear();
            session.close();
        }

        session = sessionFactory.openSession();
        try {
            Student fetchedStudent = session.get(Student.class, 1);
            System.out.println(fetchedStudent);
            System.out.println(fetchedStudent.getAddress());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.clear();
            session.close();
        }

        session = sessionFactory.openSession();
        try {
            Address fetchedAddress = session.get(Address.class, 1);
            System.out.println(fetchedAddress);
            System.out.println(fetchedAddress.getStudent());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.clear();
            session.close();
        }

    }

}
