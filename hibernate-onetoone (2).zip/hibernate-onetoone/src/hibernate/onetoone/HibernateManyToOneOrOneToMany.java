/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hibernate.onetoone;

import java.util.Date;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author Administrator
 */
public class HibernateManyToOneOrOneToMany {
    
    public static void main(String[] args) {
        
        Configuration config = new Configuration();
        config.configure();
        SessionFactory sessionFactory=  config.buildSessionFactory();
        
        
        Student student = new Student("ravi", "ravi@gmail.com", new Date(1996 - 1900, 5, 27));
        Address address = new Address("2B-7/A", "SR Nager", "Hyderabad", "Telanagana", "India", "500038");
        
        address.setStudent(student);
        
        EducationDetails sscDetails = new EducationDetails("SSC", 85.78F, 2008);
        sscDetails.setStudent(student);
        EducationDetails interDetails = new EducationDetails("Intermediate", 89.0F, 2010);
        interDetails.setStudent(student);
        EducationDetails graduationDetails = new EducationDetails("B.TECH", 71.65F, 2014);
        graduationDetails.setStudent(student);
        
        
        Session session =  sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        try{
            session.save(student);
            session.save(address);
            session.save(sscDetails);
            session.save(interDetails);
            session.save(graduationDetails);
            tx.commit();
        }catch(Exception e){
            e.printStackTrace();
            tx.rollback();
        }finally{
            session.clear();
            session.close();
        }
        
        
        
        
    }
    
}
