/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hibernate.onetoone;

/**
 *
 * @author Administrator
 */
public class EducationDetails {

    private Integer id;
    private String courseName;
    private Float percentage;
    private Integer passedOutYear;
    
    
    private Student student;

    public EducationDetails() {
    }

    public EducationDetails(Integer id, String courseName, Float percentage, Integer passedOutYear) {
        this.id = id;
        this.courseName = courseName;
        this.percentage = percentage;
        this.passedOutYear = passedOutYear;
    }

    public EducationDetails(String courseName, Float percentage, Integer passedOutYear) {
        this.courseName = courseName;
        this.percentage = percentage;
        this.passedOutYear = passedOutYear;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public Float getPercentage() {
        return percentage;
    }

    public void setPercentage(Float percentage) {
        this.percentage = percentage;
    }

    public Integer getPassedOutYear() {
        return passedOutYear;
    }

    public void setPassedOutYear(Integer passedOutYear) {
        this.passedOutYear = passedOutYear;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
    
    @Override
    public String toString() {
        return "EducationDetails{" + "id=" + id + ", courseName=" + courseName + ", percentage=" + percentage + ", passedOutYear=" + passedOutYear + '}';
    }

}
