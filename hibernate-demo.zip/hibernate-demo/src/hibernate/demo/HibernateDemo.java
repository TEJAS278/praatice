/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hibernate.demo;

import java.util.Date;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author Administrator
 */
public class HibernateDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Configuration config = new Configuration();

        // it loads hibernate.cfg.xml
        config.configure();

        // At the time building Session Factory hibernate creates all the tables in databases
        SessionFactory sessionFactory = config.buildSessionFactory();

        Student std = new Student("ravi", "ravi@gmail.com", new Date(2002 - 1900, 2, 15));

        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        try {
            session.save(std);
            tx.commit(); // in hibernate - auto commit option is false
        } catch (Exception e) {
            e.printStackTrace();
            tx.rollback();
        }finally{
            session.clear();
            session.close();
        }

    }

}
