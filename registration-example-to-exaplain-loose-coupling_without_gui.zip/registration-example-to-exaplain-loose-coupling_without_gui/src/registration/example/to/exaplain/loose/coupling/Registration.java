/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registration.example.to.exaplain.loose.coupling;

/**
 *
 * @author Administrator
 */
public class Registration {

    private PasswordGenerator passwordGenerator;
    private EMailer htmlEmailer;

    public PasswordGenerator getPasswordGenerator() {
        return passwordGenerator;
    }

    public void setPasswordGenerator(PasswordGenerator passwordGenerator) {
        this.passwordGenerator = passwordGenerator;
    }

    public EMailer getHtmlEmailer() {
        return htmlEmailer;
    }

    public void setHtmlEmailer(EMailer htmlEmailer) {
        this.htmlEmailer = htmlEmailer;
    }

    @Override
    public String toString() {
        htmlEmailer.sentEmail();
        return passwordGenerator.generatePassword();
    }

}
