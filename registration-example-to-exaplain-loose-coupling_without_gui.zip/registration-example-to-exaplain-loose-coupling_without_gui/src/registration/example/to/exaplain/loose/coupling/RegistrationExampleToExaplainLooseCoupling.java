/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registration.example.to.exaplain.loose.coupling;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

/**
 *
 * @author Administrator
 */
public class RegistrationExampleToExaplainLooseCoupling {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        BeanFactory beanFactory = new XmlBeanFactory(new ClassPathResource("spring.xml"));
        
        Registration registration = beanFactory.getBean(Registration.class);
        System.out.println(registration);

    }

}
