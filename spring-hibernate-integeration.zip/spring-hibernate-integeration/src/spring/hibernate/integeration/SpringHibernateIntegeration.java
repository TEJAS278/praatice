/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spring.hibernate.integeration;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 *
 * @author Administrator
 */
public class SpringHibernateIntegeration {

    
    public static void main(String[] args) {
        
        Person person = new Person("ravi", 25);
      
        ApplicationContext context = new AnnotationConfigApplicationContext(HibernateConfig.class);
        PersonDao personDao =  context.getBean(PersonDao.class);
        personDao.save(person);
        
        
        
    }
    
}
