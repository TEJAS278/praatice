
package com.harsha;

import javax.inject.Named;
import javax.enterprise.context.RequestScoped;


@Named(value = "message")
@RequestScoped
public class Message {

    String userName;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    
    public Message() {
    }
    
}
