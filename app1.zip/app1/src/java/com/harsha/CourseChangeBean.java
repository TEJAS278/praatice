
package com.harsha;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

/**
 *
 * @author harsha
 */
@Named(value = "ccb")
@SessionScoped
public class CourseChangeBean implements Serializable {

    
    private String courseName;
    private String result="not yet selected ";

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
    
    
    public CourseChangeBean() {
    }
    
    
    public void onSelectCourse(ValueChangeEvent vc)
    {
        System.out.println("Event Fired");
        
        String oldVal=(String)vc.getOldValue();
        String newVal=(String)vc.getNewValue();
       result="old course"+oldVal+" <br/> new course  = "+newVal;
    
       if(newVal.equals("Angular"))
       {
           result=" it is 90 days course  and click on proceed to continue";
       } else
            if(newVal.equals("Java"))
       {
           result=" it is 120 days course  and click on proceed to continue";
       } else
               if(newVal.equals("Node"))
       {
           result=" it is 30 days course  and click on proceed to continue";
       }    
       else
               {
                   result="default course is CPP";
               }

    }
    void m1(ActionEvent ae)
    {
        String s1=(String)ae.getComponent();
    }
    
}
