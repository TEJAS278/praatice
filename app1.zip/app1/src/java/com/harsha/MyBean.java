
package com.harsha;


public class MyBean 
{
    
    String nm;
    String pwd;

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
    

    public String getNm() {
        return nm;
    }

    public void setNm(String nm) {
        this.nm = nm;
    }
    
    public String checkLogin()
    {
        String un=getNm();
        if(un.equals("admin"))
        {
            System.out.println("login success username  = "+un);
            return "success";
        }
        else
        {
            System.out.println("login failed username  = "+un);
            return "failure";
        }
    }
    
}
