
package com.harsha;

/**
 *
 * @author harsha
 */
public class EvenOddBean {
    
    int num;

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
    
    
    public String findEvenOdd()
    {
        int n=getNum();

        if(n%2==0)
        {
            return "E";
        }
        else
        {
            return "O";
        }
    }
    
}
