/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hibenrate.inheritance.annotation.tableperconcreateclass;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 *
 * @author Administrator
 */

@AttributeOverrides({
    @AttributeOverride(name = "id", column = @Column(name = "id")),
    @AttributeOverride(name = "name", column = @Column(name = "name")),
    @AttributeOverride(name = "price", column = @Column(name = "price"))
}
)
@Entity
public class Furniture extends Product {
    
    @Column
    private String type;
    
    @Column
    private Integer quality;

    public Furniture() {
    }

    public Furniture(String type, Integer quality) {
        this.type = type;
        this.quality = quality;
    }

    public Furniture(String type, Integer quality, Integer id, String name, Float price) {
        super(id, name, price);
        this.type = type;
        this.quality = quality;
    }

    public Furniture(String type, Integer quality, String name, Float price) {
        super(name, price);
        this.type = type;
        this.quality = quality;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getQuality() {
        return quality;
    }

    public void setQuality(Integer quality) {
        this.quality = quality;
    }

    @Override
    public String toString() {
        return super.toString()+"Furniture{" + "type=" + type + ", quality=" + quality + '}';
    }
    
    
    
}
