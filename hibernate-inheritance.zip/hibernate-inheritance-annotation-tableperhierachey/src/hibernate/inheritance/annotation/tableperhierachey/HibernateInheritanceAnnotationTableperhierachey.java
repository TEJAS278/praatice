/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hibernate.inheritance.annotation.tableperhierachey;

import java.util.Properties;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author Administrator
 */
public class HibernateInheritanceAnnotationTableperhierachey {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Configuration confing = new Configuration();

        Properties properties = new Properties();
        properties.setProperty("hibernate.connection.driver_class", "com.mysql.cj.jdbc.Driver");
        properties.setProperty("hibernate.connection.url", "jdbc:mysql://localhost:3306/hibernatedemo");
        properties.setProperty("hibernate.connection.username", "root");
        properties.setProperty("hibernate.connection.password", "root");
        properties.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL57InnoDBDialect");
        properties.setProperty("hibernate.hbm2ddl.auto", "create");
        properties.setProperty("hibernate.show_sql", "true");
        
        
        confing.setProperties(properties);
        confing.addAnnotatedClass(Product.class);
        confing.addAnnotatedClass(Electronics.class);
        confing.addAnnotatedClass(Furniture.class);
        
        SessionFactory sessionFactory = confing.buildSessionFactory();
        
         Electronics mobile = new Electronics(6.0F, 64F, "mobile", 16000F);
        Furniture chair = new Furniture("Wooden", 2, "chair", 2000F);

        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        try {
            session.save(mobile);
            session.save(chair);
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            tx.rollback();
        } finally {
            session.clear();
            session.close();
        }

    }

}
