/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hibernate.inheritance;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author Administrator
 */
public class HibernateInheritance {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Configuration config = new Configuration();
        config.configure();
        SessionFactory sessionFactory = config.buildSessionFactory();
        
        Electronics mobile = new Electronics(6.0F, 64F, "mobile", 16000F);
        Furniture chair = new Furniture("Wooden", 2,"chair", 2000F);
        
       Session session =  sessionFactory.openSession();
       Transaction tx = session.beginTransaction();
       try{
           session.save(mobile);
           session.save(chair);
           tx.commit();
       }catch(Exception e){
           e.printStackTrace();
           tx.rollback();
       }finally{
           session.clear();
           session.close();
       }

    }

}
