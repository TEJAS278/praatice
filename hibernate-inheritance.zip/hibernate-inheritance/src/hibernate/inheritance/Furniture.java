/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hibernate.inheritance;

/**
 *
 * @author Administrator
 */
public class Furniture extends Product{
    private String type;
    private Integer quality;

    public Furniture(String type, Integer quality) {
        this.type = type;
        this.quality = quality;
    }

    public Furniture(String type, Integer quality, Integer id, String name, Float price) {
        super(id, name, price);
        this.type = type;
        this.quality = quality;
    }

    public Furniture(String type, Integer quality, String name, Float price) {
        super(name, price);
        this.type = type;
        this.quality = quality;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getQuality() {
        return quality;
    }

    public void setQuality(Integer quality) {
        this.quality = quality;
    }

    @Override
    public String toString() {
        return super.toString()+"Furniture{" + "type=" + type + ", quality=" + quality + '}';
    }
    
    
}
