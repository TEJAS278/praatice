/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hibernate.inheritance;

/**
 *
 * @author Administrator
 */
public class Electronics extends Product{
    private Float ramSize;
    private Float internalMemorySize;

    public Electronics() {
    }

    public Electronics(Float ramSize, Float internalMemorySize) {
        this.ramSize = ramSize;
        this.internalMemorySize = internalMemorySize;
    }

    public Electronics(Float ramSize, Float internalMemorySize, Integer id, String name, Float price) {
        super(id, name, price);
        this.ramSize = ramSize;
        this.internalMemorySize = internalMemorySize;
    }

    public Electronics(Float ramSize, Float internalMemorySize, String name, Float price) {
        super(name, price);
        this.ramSize = ramSize;
        this.internalMemorySize = internalMemorySize;
    }

    public Float getRamSize() {
        return ramSize;
    }

    public void setRamSize(Float ramSize) {
        this.ramSize = ramSize;
    }

    public Float getInternalMemorySize() {
        return internalMemorySize;
    }

    public void setInternalMemorySize(Float internalMemorySize) {
        this.internalMemorySize = internalMemorySize;
    }

    @Override
    public String toString() {
        return super.toString()+"Electronics{" + "ramSize=" + ramSize + ", internalMemorySize=" + internalMemorySize + '}';
    }
    
    
}
