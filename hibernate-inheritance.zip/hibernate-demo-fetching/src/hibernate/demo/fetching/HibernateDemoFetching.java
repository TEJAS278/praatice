/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hibernate.demo.fetching;

import java.util.Date;
import java.util.List;
import java.util.Properties;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;

/**
 *
 * @author Administrator
 */
public class HibernateDemoFetching {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Configuration confing = new Configuration();

        Properties properties = new Properties();
        properties.setProperty("hibernate.connection.driver_class", "com.mysql.cj.jdbc.Driver");
        properties.setProperty("hibernate.connection.url", "jdbc:mysql://localhost:3306/hibernatedemo");
        properties.setProperty("hibernate.connection.username", "root");
        properties.setProperty("hibernate.connection.password", "root");
        properties.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL57InnoDBDialect");
        properties.setProperty("hibernate.hbm2ddl.auto", "create");
        properties.setProperty("hibernate.show_sql", "true");

        confing.setProperties(properties);
        confing.addAnnotatedClass(Student.class);

        SessionFactory sessionFactory = confing.buildSessionFactory();

        Student std = new Student("ravi", "ravi", new Date(1996 - 1900, 4, 20));

        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        try {
            session.save(std);
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            tx.rollback();
        } finally {
            session.clear();
            session.close();
        }

        // get() - to fetch record based on Id
//        session = sessionFactory.openSession();
//        Student fetchedStudent = session.get(Student.class, 1);
//        System.out.println(fetchedStudent);
        // load() - to fetch record based on Id
//        session = sessionFactory.openSession();
//        Student fetchedStudent = session.load(Student.class, 1);
//        System.out.println(fetchedStudent);
        // diff b/w get() and load()
        // get() -> always hits the database to fetch the record
        // load() -> first check wethear data is present in cache memory, if data is present
        // it fetches from cache without sending request to database.
        // get() method is slower than load()
        // drawback of load() is we may not get updated data.
//        session = sessionFactory.openSession();
//        Query query = session.createQuery("From Student where name like:pattern and dateOfBirth<=: date");
//        query.setParameter("pattern", "r%");
//        query.setParameter("date", new Date(1999-1900,3,2));
//        List studentList = query.getResultList();
//        for (Object o : studentList) {
//            Student s = (Student) o;
//            System.out.println(s);
//        }
//        session = sessionFactory.openSession();
//        Query<Student> query = session.createQuery("From Student where name like:pattern and dateOfBirth<=: date", Student.class);
//        query.setParameter("pattern", "r%");
//        query.setParameter("date", new Date(1999 - 1900, 3, 2));
//        List<Student> studentList = query.getResultList();
//        for (Student s : studentList) {
//            System.out.println(s);
//        }
//        session = sessionFactory.openSession();
//        Criteria criteria = session.createCriteria(Student.class);
//        List<Student> students = criteria.list();
//        for (Student s : students) {
//            System.out.println(s);
//        }
//        session = sessionFactory.openSession();
//        Criteria criteria = session.createCriteria(Student.class);
//        criteria.add(Restrictions.like("name", "r%"));
//        List<Student> students = criteria.list();
//        for (Student s : students) {
//            System.out.println(s);
//        }


        session = sessionFactory.openSession();
        Criteria criteria = session.createCriteria(Student.class);
        Criterion nameLike = Restrictions.like("name", "%r");
        Criterion dateLessThanOrEquals = Restrictions.le("dateOfBirth", new Date(1998 - 1900, 2, 10));
        criteria.add(Restrictions.or(nameLike, dateLessThanOrEquals));
        criteria.addOrder(Order.asc("name"));
        List<Student> students = criteria.list();
        for (Student s : students) {
            System.out.println(s);
        }

    }

}
